import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useState } from "react";
import { GraduationCap, Mail, Lock, Eye, EyeOff, User, ArrowRight, Check, ArrowLeft } from "lucide-react";
import uniEdLogo from "@/assets/UniEd.png";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";

const roles = [
  { id: "student", label: "Student", icon: "🎓", description: "Access courses, submit assignments, track grades" },
  { id: "faculty", label: "Faculty", icon: "📚", description: "Create courses, manage students, grade work" },
  { id: "admin", label: "Administrator", icon: "⚙️", description: "Manage institution, users, and settings" },
];

export default function Signup() {
  const [step, setStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "",
    department: "",
    studentId: "",
  });

  const passwordStrength = () => {
    const { password } = formData;
    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[0-9]/.test(password)) strength += 25;
    if (/[^A-Za-z0-9]/.test(password)) strength += 25;
    return strength;
  };

  const getStrengthColor = () => {
    const strength = passwordStrength();
    if (strength <= 25) return "bg-destructive";
    if (strength <= 50) return "bg-orange-500";
    if (strength <= 75) return "bg-yellow-500";
    return "bg-accent";
  };

  const nextStep = () => setStep((prev) => Math.min(prev + 1, 3));
  const prevStep = () => setStep((prev) => Math.max(prev - 1, 1));

  return (
    <div className="min-h-screen flex">
      {/* Left side - Image */}
      <div className="hidden lg:flex lg:w-1/2 relative">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/90 via-primary/70 to-primary/80" />
        <img
          src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1200"
          alt="Students studying together"
          className="object-cover w-full h-full"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent" />
        
        <div className="absolute inset-0 flex flex-col justify-end p-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-display text-4xl font-bold text-white mb-4">
              Start your learning journey
            </h2>
            <p className="text-white/80 text-lg max-w-md">
              Create your account and join the community of learners and educators.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-md space-y-8"
        >
          {/* Logo and Back Button */}
          <div className="flex items-center justify-between mb-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-16 h-10 flex items-center justify-center">
                <img src={uniEdLogo} alt="UniEd" className="w-16 h-10 object-contain" />
              </div>
              <span className="font-display text-xl font-bold">UniEd</span>
            </Link>
            <Link to="/" className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
          </div>

          {/* Progress indicator */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Step {step} of 3</span>
              <span>{step === 1 ? "Basic Info" : step === 2 ? "Select Role" : "Details"}</span>
            </div>
            <Progress value={(step / 3) * 100} className="h-2" />
          </div>

          <div>
            <h1 className="font-display text-3xl font-bold mb-2">Create your account</h1>
            <p className="text-muted-foreground">
              {step === 1 && "Enter your basic information"}
              {step === 2 && "Select your role in the platform"}
              {step === 3 && "Complete your profile details"}
            </p>
          </div>

          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            {/* Step 1: Basic Info */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="name"
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="pl-10 bg-secondary/50 border-border/50"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="pl-10 bg-secondary/50 border-border/50"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Create a password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="pl-10 pr-10 bg-secondary/50 border-border/50"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  {formData.password && (
                    <div className="space-y-1">
                      <div className={`h-1 rounded-full transition-all ${getStrengthColor()}`} style={{ width: `${passwordStrength()}%` }} />
                      <p className="text-xs text-muted-foreground">
                        {passwordStrength() <= 25 && "Weak"}
                        {passwordStrength() > 25 && passwordStrength() <= 50 && "Fair"}
                        {passwordStrength() > 50 && passwordStrength() <= 75 && "Good"}
                        {passwordStrength() > 75 && "Strong"}
                      </p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Step 2: Role Selection */}
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                {roles.map((role) => (
                  <button
                    key={role.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, role: role.id })}
                    className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                      formData.role === role.id
                        ? "border-primary bg-primary/10"
                        : "border-border/50 hover:border-primary/50 bg-secondary/30"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-3xl">{role.icon}</span>
                      <div className="flex-1">
                        <div className="font-semibold">{role.label}</div>
                        <div className="text-sm text-muted-foreground">{role.description}</div>
                      </div>
                      {formData.role === role.id && (
                        <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                          <Check className="w-4 h-4 text-primary-foreground" />
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Step 3: Additional Details */}
            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    type="text"
                    placeholder="e.g., Computer Science"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="bg-secondary/50 border-border/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="studentId">
                    {formData.role === "student" ? "Student ID" : formData.role === "faculty" ? "Employee ID" : "Admin ID"}
                  </Label>
                  <Input
                    id="studentId"
                    type="text"
                    placeholder={`Enter your ${formData.role === "student" ? "student" : "employee"} ID`}
                    value={formData.studentId}
                    onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                    className="bg-secondary/50 border-border/50"
                  />
                </div>
              </motion.div>
            )}

            {/* Navigation buttons */}
            <div className="flex gap-4">
              {step > 1 && (
                <Button type="button" variant="outline" onClick={prevStep} className="flex-1">
                  Back
                </Button>
              )}
              <Button
                type={step === 3 ? "submit" : "button"}
                onClick={step < 3 ? nextStep : undefined}
                className="flex-1 bg-gradient-to-r from-primary to-accent text-primary-foreground"
              >
                {step === 3 ? "Create Account" : "Continue"}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </form>

          <p className="text-center text-muted-foreground">
            Already have an account?{" "}
            <Link to="/login" className="text-primary hover:underline font-medium">
              Sign in
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
