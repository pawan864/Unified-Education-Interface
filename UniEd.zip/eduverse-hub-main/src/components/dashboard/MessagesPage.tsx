import { motion } from "framer-motion";
import { useState } from "react";
import { Search, Send, Paperclip, MoreVertical, Phone, Video, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/contexts/AuthContext";

const conversations = [
  {
    id: 1,
    name: "Dr. Sarah Smith",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
    lastMessage: "Great work on your project presentation!",
    time: "2m ago",
    unread: 2,
    online: true,
    role: "Faculty",
  },
  {
    id: 2,
    name: "CS301 Study Group",
    avatar: "",
    lastMessage: "Anyone free to study tonight?",
    time: "15m ago",
    unread: 5,
    online: false,
    isGroup: true,
    members: 8,
  },
  {
    id: 3,
    name: "Mike Johnson",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
    lastMessage: "Thanks for sharing the notes!",
    time: "1h ago",
    unread: 0,
    online: true,
    role: "Student",
  },
  {
    id: 4,
    name: "Academic Advisor",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100",
    lastMessage: "Your course registration is confirmed.",
    time: "2h ago",
    unread: 0,
    online: false,
    role: "Admin",
  },
];

const messages = [
  {
    id: 1,
    senderId: "other",
    text: "Hi! I wanted to discuss your recent assignment submission.",
    time: "10:30 AM",
  },
  {
    id: 2,
    senderId: "me",
    text: "Of course! I'd be happy to discuss it. What would you like to know?",
    time: "10:32 AM",
  },
  {
    id: 3,
    senderId: "other",
    text: "Your implementation of the binary search tree was excellent. I particularly liked your approach to balancing.",
    time: "10:35 AM",
  },
  {
    id: 4,
    senderId: "me",
    text: "Thank you! I spent extra time on the AVL rotation functions to make sure they were efficient.",
    time: "10:37 AM",
  },
  {
    id: 5,
    senderId: "other",
    text: "Great work on your project presentation! The visualization component was very impressive.",
    time: "10:40 AM",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { opacity: 1, y: 0 },
};

export function MessagesPage() {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState(conversations[0]);
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredConversations = conversations.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="h-[calc(100vh-8rem)]"
    >
      <div className="glass rounded-xl border border-border/50 h-full flex overflow-hidden">
        {/* Conversations sidebar */}
        <div className="w-full md:w-80 border-r border-border/50 flex flex-col">
          <div className="p-4 border-b border-border/50">
            <h2 className="text-lg font-semibold mb-3">Messages</h2>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 bg-secondary/50"
              />
            </div>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-2">
              {filteredConversations.map((conversation) => (
                <motion.button
                  key={conversation.id}
                  variants={itemVariants}
                  onClick={() => setSelectedConversation(conversation)}
                  className={`w-full p-3 rounded-lg flex items-center gap-3 transition-colors ${
                    selectedConversation.id === conversation.id
                      ? "bg-primary/10"
                      : "hover:bg-secondary/50"
                  }`}
                >
                  <div className="relative">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={conversation.avatar} />
                      <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-primary-foreground">
                        {conversation.isGroup ? conversation.members : conversation.name.split(" ").map(n => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    {conversation.online && (
                      <Circle className="absolute bottom-0 right-0 w-3 h-3 fill-success text-success" />
                    )}
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-medium truncate">{conversation.name}</span>
                      <span className="text-xs text-muted-foreground">{conversation.time}</span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{conversation.lastMessage}</p>
                  </div>
                  {conversation.unread > 0 && (
                    <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                      {conversation.unread}
                    </span>
                  )}
                </motion.button>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Chat area */}
        <div className="hidden md:flex flex-1 flex-col">
          {/* Chat header */}
          <div className="p-4 border-b border-border/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={selectedConversation.avatar} />
                <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-primary-foreground">
                  {selectedConversation.name.split(" ").map(n => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium">{selectedConversation.name}</h3>
                <span className="text-xs text-muted-foreground">
                  {selectedConversation.online ? "Online" : "Offline"}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon">
                <Phone className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon">
                <Video className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.senderId === "me" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[70%] p-3 rounded-2xl ${
                      message.senderId === "me"
                        ? "bg-gradient-to-r from-primary to-accent text-primary-foreground rounded-br-sm"
                        : "bg-secondary rounded-bl-sm"
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <span className={`text-xs mt-1 block ${
                      message.senderId === "me" ? "text-primary-foreground/70" : "text-muted-foreground"
                    }`}>
                      {message.time}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </ScrollArea>

          {/* Message input */}
          <div className="p-4 border-t border-border/50">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon">
                <Paperclip className="w-4 h-4" />
              </Button>
              <Input
                placeholder="Type a message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                className="flex-1 bg-secondary/50"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && newMessage.trim()) {
                    setNewMessage("");
                  }
                }}
              />
              <Button 
                size="icon" 
                className="bg-gradient-to-r from-primary to-accent"
                disabled={!newMessage.trim()}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile: Show conversation list or chat based on selection */}
        <div className="md:hidden flex-1 flex flex-col">
          {/* Same chat content for mobile */}
        </div>
      </div>
    </motion.div>
  );
}
