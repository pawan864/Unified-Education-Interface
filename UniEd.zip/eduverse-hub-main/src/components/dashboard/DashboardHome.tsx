import { motion } from "framer-motion";
import {
  BookOpen,
  ClipboardList,
  Calendar,
  Award,
  Clock,
  TrendingUp,
  Bell,
  ChevronRight,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const stats = [
  {
    title: "Total Courses",
    value: "6",
    change: "+2 this semester",
    icon: BookOpen,
    gradient: "from-blue-500 to-indigo-600",
  },
  {
    title: "Pending Assignments",
    value: "4",
    change: "3 due this week",
    icon: ClipboardList,
    gradient: "from-orange-500 to-red-500",
  },
  {
    title: "Attendance Rate",
    value: "94%",
    change: "+2% from last month",
    icon: Calendar,
    gradient: "from-emerald-500 to-teal-600",
  },
  {
    title: "Average GPA",
    value: "3.85",
    change: "+0.15 from last semester",
    icon: Award,
    gradient: "from-yellow-500 to-orange-500",
  },
];

const upcomingDeadlines = [
  {
    title: "Data Structures Assignment 3",
    course: "CS 201",
    dueDate: "2 days",
    progress: 65,
    urgent: true,
  },
  {
    title: "Physics Lab Report",
    course: "PHY 101",
    dueDate: "5 days",
    progress: 30,
    urgent: false,
  },
  {
    title: "Literature Essay",
    course: "ENG 102",
    dueDate: "1 week",
    progress: 0,
    urgent: false,
  },
];

const recentCourses = [
  {
    name: "Data Structures & Algorithms",
    instructor: "Dr. Sarah Chen",
    progress: 72,
    image: "https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=400",
  },
  {
    name: "Calculus II",
    instructor: "Prof. Michael Torres",
    progress: 58,
    image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400",
  },
  {
    name: "Introduction to Physics",
    instructor: "Dr. Emily Watson",
    progress: 85,
    image: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=400",
  },
];

const announcements = [
  {
    title: "Final Exam Schedule Released",
    time: "2 hours ago",
    priority: "high",
  },
  {
    title: "New Course Materials Available",
    time: "5 hours ago",
    priority: "medium",
  },
  {
    title: "Library Hours Extended",
    time: "1 day ago",
    priority: "low",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function DashboardHome() {
  const currentHour = new Date().getHours();
  const greeting = currentHour < 12 ? "Good morning" : currentHour < 18 ? "Good afternoon" : "Good evening";

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Welcome banner */}
      <motion.div variants={itemVariants}>
        <Card className="glass border-border/50 overflow-hidden">
          <div className="relative p-6 md:p-8">
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
            <div className="relative">
              <h1 className="font-display text-2xl md:text-3xl font-bold mb-2">
                {greeting}, John! 👋
              </h1>
              <p className="text-muted-foreground">
                You have <span className="text-primary font-semibold">3 assignments</span> due this week.
                Keep up the great work!
              </p>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Stats grid */}
      <motion.div variants={itemVariants} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="glass border-border/50 hover:bg-card/80 transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/5">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{stat.title}</p>
                    <p className="text-3xl font-bold font-display">{stat.value}</p>
                    <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-accent" />
                      {stat.change}
                    </p>
                  </div>
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Upcoming deadlines */}
        <motion.div variants={itemVariants} className="lg:col-span-2">
          <Card className="glass border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="font-display text-lg">Upcoming Deadlines</CardTitle>
              <Button variant="ghost" size="sm" className="text-primary">
                View all <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingDeadlines.map((deadline, index) => (
                <motion.div
                  key={deadline.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-4 p-4 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors"
                >
                  <div className={`w-3 h-3 rounded-full ${deadline.urgent ? "bg-destructive animate-pulse" : "bg-accent"}`} />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{deadline.title}</p>
                    <p className="text-sm text-muted-foreground">{deadline.course}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${deadline.urgent ? "text-destructive" : "text-muted-foreground"}`}>
                      <Clock className="w-3 h-3 inline mr-1" />
                      {deadline.dueDate}
                    </p>
                    <div className="w-24 mt-1">
                      <Progress value={deadline.progress} className="h-1.5" />
                    </div>
                  </div>
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        {/* Announcements */}
        <motion.div variants={itemVariants}>
          <Card className="glass border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="font-display text-lg flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Announcements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {announcements.map((announcement, index) => (
                <motion.div
                  key={announcement.title}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-3 rounded-lg hover:bg-secondary/30 transition-colors cursor-pointer"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      announcement.priority === "high" ? "bg-destructive" :
                      announcement.priority === "medium" ? "bg-yellow-500" : "bg-accent"
                    }`} />
                    <div>
                      <p className="text-sm font-medium">{announcement.title}</p>
                      <p className="text-xs text-muted-foreground">{announcement.time}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Recent courses */}
      <motion.div variants={itemVariants}>
        <Card className="glass border-border/50">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="font-display text-lg">Your Courses</CardTitle>
            <Link to="/dashboard/courses">
              <Button variant="ghost" size="sm" className="text-primary">
                View all <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentCourses.map((course, index) => (
                <motion.div
                  key={course.name}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="group relative rounded-xl overflow-hidden border border-border/50 hover:border-primary/50 transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10"
                >
                  <div className="aspect-video relative">
                    <img
                      src={course.image}
                      alt={course.name}
                      className="w-full h-full object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold mb-1 group-hover:text-primary transition-colors">
                      {course.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-3">{course.instructor}</p>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-medium">{course.progress}%</span>
                      </div>
                      <Progress value={course.progress} className="h-1.5" />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
